package com.example.brick_breaker

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
