package com.example.brickbreaker

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
