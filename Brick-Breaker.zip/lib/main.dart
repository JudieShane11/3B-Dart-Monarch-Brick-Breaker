// Copyright 2020 The Flutter Authors. All rights reserved.
// Introduction to Flame with Flutter
// https://codelabs.developers.google.com/codelabs/flutter-flame-brick-breaker

import 'package:flutter/material.dart';

import 'src/widgets/game_app.dart';

void main() {
  runApp(const GameApp());
}
